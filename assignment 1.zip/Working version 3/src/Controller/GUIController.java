package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.ConcurrentModificationException;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import Model.Baggage;
import Model.Log;
import Model.Passenger;
import Model.PassengersInQueue;


import View.GUIMain;

/**
 *  Advanced Software Engineering Assignment Stage 2 - Coursework Class that implements the 
 *  methods such as Main Listener and Action Listener which control and handle user events 
 *  that occur in the View or GUI Main. This class is key to the Model-View-Controller (MVC)
 *  architecture that has been used in this programme.
 *  
 *  
 * 
 * @author Cameron Scott, Kuda Mugara, Lynsey Kirk, Rachana Patel, Robert Stone
 *
 */
public class GUIController {

	private PassengersInQueue passengersinqueue;

	private GUIMain view1;

	/**
	 * @param q		Passengers in queue
	 * @param v1	GUI view
	 */
	public GUIController(PassengersInQueue q, GUIMain v1) {

		passengersinqueue = q;

		view1 = v1;

		view1.addGUIMainListener(new GUIMainController());

	}

	class GUIMainController implements ActionListener

	{
		public void actionPerformed(ActionEvent e) {
			
			
			// method that will trigger the programme
			view1.disableProcessButton();

			// method that will dictate the display onto GUI
			view1.startDisplay();

			SwingUtilities.invokeLater(new Runnable() {

				@Override
				public void run() {

					new GUIMain("SwingWorker CheckIn");

				}

			});

		}

	}

}
