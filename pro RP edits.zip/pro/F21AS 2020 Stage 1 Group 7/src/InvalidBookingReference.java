
public class InvalidBookingReference extends Exception {
	 
	public void MyException(String s) 
	    { 
	        // Call constructor of parent Exception 
	        System.out.println("Invalid booking reference number. Please enter 10 digit reference number."); 
	    } 

}
